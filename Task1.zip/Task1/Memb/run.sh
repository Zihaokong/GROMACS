#!/bin/bash
#SBATCH --job-name=gromacs     # Job name
#SBATCH --nodes=5                    # Run all processes on a single node	
#SBATCH --partition=hpc
#SBATCH --ntasks-per-node=30
#SBATCH --cpus-per-task=4                   # Run a single task		
#SBATCH --time=04:00:00              # Time limit hrs:min:sec
#SBATCH --output=parallel_%j.log     # Standard output and error log


module purge
module load gcc-9.2.0
module load mpi/impi
source ~/spack/share/spack/setup-env.sh
spack compiler find
spack load hwloc
export PATH=$PATH:/usr/local/cuda-11.0/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-11.0/lib64

source ~/gromacs2020/bin/GMXRC




cp topol.tpr result5
cd result5


# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-2.log -v 
# rm conf* state* ener* traj*


mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun  -s topol.tpr -g md110-1.log -v 
rm conf* state* ener* traj*
mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-2.log -v 
rm conf* state* ener* traj*
mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-3.log -v 
rm conf* state* ener* traj*
mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun  -s topol.tpr -g md110-4.log -v 
rm conf* state* ener* traj*
mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-5.log -v 

# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-5.log -v 

# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-5.log -v 


# mpirun -np 30 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md30-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 30 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md30-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 30 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md30-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 30 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md30-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 30 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md30-5.log -v 

