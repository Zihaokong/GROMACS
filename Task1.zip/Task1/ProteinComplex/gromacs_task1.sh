#!/bin/bash
#SBATCH --job-name=gromacs     # Job name
#SBATCH --nodes=5                    # Run all processes on a single node	
#SBATCH --partition=hpc
#SBATCH --ntasks-per-node=30
#SBATCH --cpus-per-task=4                   # Run a single task		
#SBATCH --time=09:00:00              # Time limit hrs:min:sec
#SBATCH --output=parallel_%j.log     # Standard output and error log


module purge
module load gcc-9.2.0
module load mpi/impi
source ~/spack/share/spack/setup-env.sh
spack compiler find
spack load hwloc
export PATH=$PATH:/usr/local/cuda-11.0/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-11.0/lib64

source ~/gromacs2020/bin/GMXRC



mkdir result
cp topol.tpr result
cd result
mpirun -np 150 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md150-1.log 
rm conf* state* ener* traj*
mpirun -np 150 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md150-2.log 
rm conf* state* ener* traj*
mpirun -np 150 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md150-3.log -v 
rm conf* state* ener* traj*
mpirun -np 150 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md150-4.log -v 
rm conf* state* ener* traj*
mpirun -np 150 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md150-5.log -v 
rm conf* state* ener* traj*

# mpirun -np 125 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md125-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 125 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md125-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 125 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md125-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 125 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md125-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 125 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md125-5.log -v 
# rm conf* state* ener* traj*



# mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 110 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md110-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 105 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md105-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 105 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md105-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 105 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md105-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 105 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md105-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 105 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md105-5.log -v 
# rm conf* state* ener* traj*



# mpirun -np 100 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md100-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 100 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md100-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 100 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md100-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 100 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md100-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 100 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md100-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 90 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md90-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 90 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md90-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 90 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md90-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 90 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md90-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 90 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md90-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 75 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md75-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 60 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md60-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 50 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md50-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 50 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md50-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 50 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md50-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 50 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md50-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 50 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md50-5.log -v 
# rm conf* state* ener* traj*

# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-1.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-2.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-3.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-4.log -v 
# rm conf* state* ener* traj*
# mpirun -np 40 -genv I_MPI_PIN_DOMAIN=omp:compact -genv OMP_NUM_THREADS=4  gmx_mpi mdrun -s topol.tpr -g md40-5.log -v 
# rm conf* state* ener* traj*


